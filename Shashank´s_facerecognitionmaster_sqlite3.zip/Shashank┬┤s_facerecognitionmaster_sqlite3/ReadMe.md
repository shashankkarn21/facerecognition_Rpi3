hello friends!
in this folder you will find code for face recognition along with database setup

this setup is for usb webcam
ill upload for pi cam aswell
as soon as i finish it

first you will have to download sqlite3 by typing in terminal

sudo apt-get install sqlite3 

this will install the latest version of sqlite

now you will have to go to the directory in which you have saved this folder

now, just type 

sqlite3 FaceBase.db

this will create the database in which you will store the image details

now terminal will show sqlite>

so type

BEGIN;

then 

CREATE TABLE faces(Id INTEGER PRIMARYKEY, name TEXT PRIMARYKEY, age TEXT, gen TEXT, cr TEXT);

this will create a table 

now type

COMMIT;

now the setup of data base is done
now just execute the Face_DataBase.py 
while executing it will ask id, name, age , gender, and phone number

like this

Enter User Id:1
Enter User Name:"shashank karn"
Enter User Age:20
Enter User Gender:"male"
Enter User Mobile no. :9869150300

NOTE:
enter your name and gender with double quotes like above

now simply execute the face_training.py

and then face_recognition.py

congrats!! you have created your own data base setup of faces and will be shown
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!





