import io
import picamera 
import cv2
import numpy

import os 

def assure_path_exists(path):
    dir = os.path.dirname(path)
    if not os.path.exists(dir):
        os.makedirs(dir)
#Create a memory stream so photos doesn't need to be saved in a file
stream = io.BytesIO()
recognizer = cv2.face.LBPHFaceRecognizer_create()
#recognizer = cv2.face.EigenFaceRecognizer_create()
#recognizer = cv2.face.FisherFaceRecognizer_create()

assure_path_exists("trainer/")

# Load the trained mode
recognizer.read('trainer/trainer.yml')

# Load prebuilt model for Frontal Face
cascadePath = "haarcascade_frontalface_default.xml"

# Create classifier from prebuilt model
faceCascade = cv2.CascadeClassifier(cascadePath);

# Set the font style
font = cv2.FONT_HERSHEY_SIMPLEX
#Get the picture (low resolution, so it should be quite fast)
#Here you can also specify other parameters (e.g.:rotate the image)
with picamera.PiCamera() as camera:
    camera.resolution = (1280,960)
    camera.capture(stream, format='jpeg')

#Convert the picture into a numpy array
buff = numpy.fromstring(stream.getvalue(), dtype=numpy.uint8)

#Now creates an OpenCV image
im = cv2.imdecode(buff, 1)

#Load a cascade file for detecting faces
face_cascade = cv2.CascadeClassifier('/home/pi/opencv-3.3.0/data/haarcascades/haarcascade_frontalface_default.xml')

#Convert to grayscale
gray = cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)

#Look for faces in the image using the loaded cascade file
faces = face_cascade.detectMultiScale(gray, 1.1, 5)

print ("Found" +str(len(faces))+ " face(s)")

#Draw a rectangle around every found face
for (x,y,w,h) in faces:
    cv2.rectangle(im,(x,y),(x+w,y+h),(255,255,0),2)
    
    Id, garbage = recognizer.predict(gray[y:y+h,x:x+w])
        #uId = float(''.join(map(str,Id)))
        # Check the ID if exist
    print ("Id=" +str(Id)+" garbage= "+str(garbage))
        #print ("user no="+str(uId))
        #if(Id == 1,):
         #   uId = "shashank"
        #If not exist, then it is Unknown
        if(Id == 1 and garbage <= 60):
            namedis= "xxxx" #write your name in place of xxxx
        #if(Id != 1,):
         #s   uId = "unknown"
         
        if(Id != 1 or garbage >60):
            namedis = "unknown"
        # Put text describe who is in the picture
    cv2.rectangle(im, (x-22,y-60), (x+w+22, y-22), (0,200,0), -1)
    cv2.putText(im, str(namedis), (x,y-30), font, 1, (255,255,255), 3)

#Save the result image
cv2.imwrite('result.jpg',im)
cv2.imshow('welcome '+str(namedis),im) 

