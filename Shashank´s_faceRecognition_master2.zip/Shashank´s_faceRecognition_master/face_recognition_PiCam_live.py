# import the necessary packages
from picamera.array import PiRGBArray
from picamera import PiCamera
import time
import cv2
import os 

def assure_path_exists(path):
    dir = os.path.dirname(path)
    if not os.path.exists(dir):
        os.makedirs(dir)

# Create Local Binary Patterns Histograms for face recognization
recognizer = cv2.face.LBPHFaceRecognizer_create()
#recognizer = cv2.face.EigenFaceRecognizer_create()
#recognizer = cv2.face.FisherFaceRecognizer_create()

assure_path_exists("trainer/")

# Load the trained mode
recognizer.read('trainer/trainer.yml')

# Load prebuilt model for Frontal Face
cascadePath = "haarcascade_frontalface_default.xml"

# Create classifier from prebuilt model
faceCascade = cv2.CascadeClassifier(cascadePath);

# Set the font style
font = cv2.FONT_HERSHEY_SIMPLEX


 
# initialize the camera and grab a reference to the raw camera capture
camera = PiCamera()
camera.resolution = (640, 480)
camera.framerate = 32
rawCapture = PiRGBArray(camera, size=(640, 480))
 
# allow the camera to warmup
time.sleep(0.1)
 
# capture frames from the camera
for frame in camera.capture_continuous(rawCapture, format="bgr", use_video_port=True):
	# grab the raw NumPy array representing the image, then initialize the timestamp
	# and occupied/unoccupied text
    im = frame.array
    gray = cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)

    # Get all face from the video frame
    faces = faceCascade.detectMultiScale(gray, 1.1,5)

    # For each face in faces
    for(x,y,w,h) in faces:

        # Create rectangle around the face
        cv2.rectangle(im, (x-20,y-20), (x+w+20,y+h+20), (0,255,0), 4)

        # Recognize the face belongs to which ID
        Id, garbage = recognizer.predict(gray[y:y+h,x:x+w])
        #uId = float(''.join(map(str,Id)))
        # Check the ID if exist
        print ("Id=" +str(Id)+" garbage= "+str(garbage))
        #print ("user no="+str(uId))
        #if(Id == 1,):
         #   uId = "shashank"
        #If not exist, then it is Unknown
        if(Id == 1 and garbage <= 60):
            namedis= "xxxx" #write your name in place of xxxx
        #if(Id != 1,):
         #s   uId = "unknown"
         
        if(Id != 1 or garbage >60):
            namedis = "unknown"
        # Put text describe who is in the picture
        cv2.rectangle(im, (x-22,y-60), (x+w+22, y-22), (0,200,0), -1)
        cv2.putText(im, str(namedis), (x,y-30), font, 1, (255,255,255), 3)

 
	# show the frame
    cv2.imshow('welcome '+str(namedis),im)
    key = cv2.waitKey(1) & 0xFF
 
	# clear the stream in preparation for the next frame
    rawCapture.truncate(0)
 
	# if the `q` key was pressed, break from the loop
    if key == ord("q"):
            break

