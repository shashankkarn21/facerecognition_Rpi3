hello Friends!
I´m shashank and i am here to help you with the face recognition using raspberry-Pi 3 and opencv 

the steps to use to recognize your face are divided into two major parts

1-using USB camera
2-using PiCamera

part-1:
-first we need to create a set of images so that we can use it for training
	for the use face_datasets.py the images will be stored in dataset folder 
	for people using picam use face_dataset_picam.py  
-then we can use training.py so that we can create our own trainer.yml file 
	which will be stored in trainer folder
-Now that we have our own yml file we can use it for recognizing our face
	just use face_recognition.py running this code will enable you to detect your face using 
	a regular USB web camera
	for people using picam use face-recognition_Picam_live.py

part-2
-Now that we have our own Code running we can simply use face_recognition_PiCam_stillimage.py
	to recognize our face using PiCam in still image mode
-For recognizing in live video mode use face_recognition_PiCam_live.py 
